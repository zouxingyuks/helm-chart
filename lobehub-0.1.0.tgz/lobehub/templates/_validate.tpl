{{/*
渲染期校验规则 — 在 deployment.yaml 顶部 include 触发
*/}}
{{- define "lobehub.validate" -}}

{{/*
规则 1: AUTH_SECRET 必需（existingSecret 模式除外）
*/}}
{{- if not .Values.auth.existingSecret }}
{{- if not .Values.auth.authSecret }}
{{- fail "ERROR: auth.authSecret is required. LobeHub needs AUTH_SECRET for NextAuth signing. Please provide it using --set auth.authSecret=<your-secret> or use --set auth.existingSecret=<secret-name> to reference an existing Secret." }}
{{- end }}

{{/*
规则 2: KEY_VAULTS_SECRET 必需（existingSecret 模式除外）
*/}}
{{- if not .Values.auth.keyVaultsSecret }}
{{- fail "ERROR: auth.keyVaultsSecret is required. LobeHub needs KEY_VAULTS_SECRET for encrypting key vaults. Please provide it using --set auth.keyVaultsSecret=<your-secret> or use --set auth.existingSecret=<secret-name> to reference an existing Secret." }}
{{- end }}
{{- end }}

{{/*
规则 3: database 内部启用时不允许同时提供外部 URL
*/}}
{{- if and .Values.database.internal.enabled .Values.database.url }}
{{- fail "ERROR: database.internal.enabled and database.url are mutually exclusive. When using the internal database (database.internal.enabled=true), do not set database.url. Either disable the internal database or remove the external URL." }}
{{- end }}

{{/*
规则 4: redis 内部启用时不允许同时提供外部 URL
*/}}
{{- if and .Values.redis.internal.enabled .Values.redis.url }}
{{- fail "ERROR: redis.internal.enabled and redis.url are mutually exclusive. When using the internal Redis (redis.internal.enabled=true), do not set redis.url. Either disable the internal Redis or remove the external URL." }}
{{- end }}

{{/*
规则 5: ingress 启用时 hostname 不能为空
*/}}
{{- if and .Values.ingress.enabled (not .Values.ingress.hostname) }}
{{- fail "ERROR: ingress.hostname is required when ingress.enabled is true. Please provide it using --set ingress.hostname=<your-domain>." }}
{{- end }}

{{- end -}}
