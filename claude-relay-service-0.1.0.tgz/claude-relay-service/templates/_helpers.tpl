{{/*
Common labels
*/}}
{{- define "claude-relay-service.labels" -}}
helm.sh/chart: {{ include "claude-relay-service.chart" . }}
{{ include "claude-relay-service.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "claude-relay-service.selectorLabels" -}}
app.kubernetes.io/name: {{ include "claude-relay-service.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "claude-relay-service.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "claude-relay-service.fullname" -}}
{{- if .Values.fullnameOverride -}}
    {{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
    {{- $name := default .Chart.Name .Values.nameOverride -}}
    {{- if contains $name .Release.Name -}}
        {{- .Release.Name | trunc 63 | trimSuffix "-" -}}
    {{- else -}}
        {{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
    {{- end -}}
{{- end -}}
{{- end }}

{{/*
Create the name of the service to use
*/}}
{{- define "claude-relay-service.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Return the proper Docker Image Registry Secret Names for persistence
*/}}
{{- define "claude-relay-service.dataPersistentVolumeClaimName" -}}
{{- if .Values.persistence.data.existingClaim -}}
    {{- .Values.persistence.data.existingClaim -}}
{{- else -}}
    {{- printf "%s-data" (include "claude-relay-service.fullname" .) -}}
{{- end -}}
{{- end -}}

{{- define "claude-relay-service.logsPersistentVolumeClaimName" -}}
{{- if .Values.persistence.logs.existingClaim -}}
    {{- .Values.persistence.logs.existingClaim -}}
{{- else -}}
    {{- printf "%s-logs" (include "claude-relay-service.fullname" .) -}}
{{- end -}}
{{- end -}}